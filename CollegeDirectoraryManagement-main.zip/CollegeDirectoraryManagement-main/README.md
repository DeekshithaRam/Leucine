# CollegeDirectoraryManagement
Leucine Assignment<br>
CollegeDirectoryApplication: This directory contains the backend code, implemented using Spring Boot.<br>
collegedirecotrymanagement: This directory contains the frontend code, implemented using React.js.
